import java.awt.EventQueue;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;

import javax.swing.JFrame;
import java.awt.CardLayout;
import javax.swing.SpringLayout;
import java.awt.Color;
import java.awt.SystemColor;
import java.awt.TextArea;
import java.awt.List;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.JToggleButton;

public class HUI3 {

	private JFrame frame;
	private JTextField t1;
	private JTextField t2;
	private JTextField t3;
	private JTextField t4;
	private JTextField t5;
	Connection connection;
	Statement statement;
	ResultSet rs;
	List list = new List(10);
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					HUI3 window = new HUI3();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public HUI3() {
		try 
		{
			Class.forName("oracle.jdbc.driver.OracleDriver");
		} 
		catch (Exception e) 
		{
			System.err.println("Unable to find and load driver");
			System.exit(1);
		}
		connectToDB();
		initialize();
	}
	public void connectToDB() 
    {
		try 
		{
		  connection = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","greta","GRETA0910");
		  statement = connection.createStatement();

		} 
		catch (SQLException connectException) 
		{
		  System.out.println(connectException.getMessage());
		  System.out.println(connectException.getSQLState());
		  System.out.println(connectException.getErrorCode());
		  System.exit(1);
		}
    }
	private void loadList() 
	{	   
		try 
		{
		  rs = statement.executeQuery("SELECT * FROM hotels");
		  while (rs.next()) 
		  {
			list.add(rs.getString("HID"));
		  }
		} 
		catch (SQLException e) 
		{ 
		  System.out.println(e.getMessage());
		}
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.getContentPane().setBackground(SystemColor.activeCaption);
		frame.getContentPane().setForeground(new Color(0, 0, 0));
		frame.setBounds(100, 100, 450, 300);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		SpringLayout springLayout = new SpringLayout();
		frame.getContentPane().setLayout(springLayout);
		
		TextArea ftf = new TextArea();
		springLayout.putConstraint(SpringLayout.NORTH, ftf, -82, SpringLayout.SOUTH, frame.getContentPane());
		springLayout.putConstraint(SpringLayout.WEST, ftf, 203, SpringLayout.WEST, frame.getContentPane());
		springLayout.putConstraint(SpringLayout.SOUTH, ftf, -10, SpringLayout.SOUTH, frame.getContentPane());
		springLayout.putConstraint(SpringLayout.EAST, ftf, -46, SpringLayout.EAST, frame.getContentPane());
		frame.getContentPane().add(ftf);
	
		list.addItemListener(new ItemListener() {
			public void itemStateChanged(ItemEvent arg0) {
				try 
				{
					rs = statement.executeQuery("SELECT * FROM hotels");
					while (rs.next()) 
					{
						if (rs.getString("HID").equals(list.getSelectedItem()))
						break;
					}
					if (!rs.isAfterLast()) 
					{
						t1.setText(rs.getString("HID"));
						t2.setText(rs.getString("NAME"));
						t3.setText(rs.getString("CONTACT"));
						t4.setText(rs.getString("EMAIL_ID"));
						t5.setText(rs.getString("ADDRESS"));
					}
				} 
				catch (SQLException selectException) 
				{
					ftf.append(selectException.getMessage());
				}
				
			}
		});
		loadList();
		springLayout.putConstraint(SpringLayout.NORTH, list, 10, SpringLayout.NORTH, frame.getContentPane());
		springLayout.putConstraint(SpringLayout.WEST, list, 10, SpringLayout.WEST, frame.getContentPane());
		frame.getContentPane().add(list);
		
		JLabel lblHotelId = new JLabel("Hotel Id:");
		springLayout.putConstraint(SpringLayout.NORTH, lblHotelId, 21, SpringLayout.NORTH, frame.getContentPane());
		springLayout.putConstraint(SpringLayout.WEST, lblHotelId, 25, SpringLayout.EAST, list);
		frame.getContentPane().add(lblHotelId);
		
		JLabel lblHotelName = new JLabel("Hotel Name:");
		springLayout.putConstraint(SpringLayout.WEST, lblHotelName, 13, SpringLayout.EAST, list);
		frame.getContentPane().add(lblHotelName);
		
		JLabel lblContact = new JLabel("Contact:");
		springLayout.putConstraint(SpringLayout.SOUTH, lblHotelName, -6, SpringLayout.NORTH, lblContact);
		springLayout.putConstraint(SpringLayout.NORTH, lblContact, 83, SpringLayout.NORTH, frame.getContentPane());
		springLayout.putConstraint(SpringLayout.WEST, lblContact, 0, SpringLayout.WEST, lblHotelId);
		frame.getContentPane().add(lblContact);
		
		JLabel lblEmailId = new JLabel("email id:");
		springLayout.putConstraint(SpringLayout.NORTH, lblEmailId, 6, SpringLayout.SOUTH, lblContact);
		springLayout.putConstraint(SpringLayout.EAST, lblEmailId, 0, SpringLayout.EAST, lblHotelId);
		frame.getContentPane().add(lblEmailId);
		
		JLabel lblAddress = new JLabel("Address:");
		springLayout.putConstraint(SpringLayout.NORTH, lblAddress, 6, SpringLayout.SOUTH, lblEmailId);
		springLayout.putConstraint(SpringLayout.WEST, lblAddress, 0, SpringLayout.WEST, lblHotelId);
		frame.getContentPane().add(lblAddress);
		
		t1 = new JTextField();
		springLayout.putConstraint(SpringLayout.NORTH, t1, 10, SpringLayout.NORTH, frame.getContentPane());
		springLayout.putConstraint(SpringLayout.EAST, t1, -10, SpringLayout.EAST, frame.getContentPane());
		frame.getContentPane().add(t1);
		t1.setColumns(10);
		
		t2 = new JTextField();
		springLayout.putConstraint(SpringLayout.NORTH, t2, 6, SpringLayout.SOUTH, t1);
		springLayout.putConstraint(SpringLayout.WEST, t2, 6, SpringLayout.EAST, lblHotelName);
		frame.getContentPane().add(t2);
		t2.setColumns(10);
		
		t3 = new JTextField();
		springLayout.putConstraint(SpringLayout.NORTH, t3, 6, SpringLayout.SOUTH, t2);
		springLayout.putConstraint(SpringLayout.EAST, t3, 0, SpringLayout.EAST, t1);
		frame.getContentPane().add(t3);
		t3.setColumns(10);
		
		t4 = new JTextField();
		springLayout.putConstraint(SpringLayout.NORTH, t4, -3, SpringLayout.NORTH, lblEmailId);
		springLayout.putConstraint(SpringLayout.EAST, t4, 0, SpringLayout.EAST, t1);
		frame.getContentPane().add(t4);
		t4.setColumns(10);
		
		t5 = new JTextField();
		springLayout.putConstraint(SpringLayout.NORTH, t5, -3, SpringLayout.NORTH, lblAddress);
		springLayout.putConstraint(SpringLayout.EAST, t5, 0, SpringLayout.EAST, t1);
		frame.getContentPane().add(t5);
		t5.setColumns(10);
		
		JToggleButton tglbtnDelete = new JToggleButton("delete");
		tglbtnDelete.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			
				try{
					Statement statement = connection.createStatement();
					int i = statement.executeUpdate("DELETE FROM HOTELS WHERE HID = "+ list.getSelectedItem());
					ftf.append("\nDeleted " + i + " rows successfully");
					t1.setText(null);
					t2.setText(null);
					t3.setText(null);
					t4.setText(null);
					t5.removeAll();
					loadList();
				} 
				catch (SQLException insertException) 
				{
					ftf.append(insertException.getMessage());
				}
				
			}
		});
		springLayout.putConstraint(SpringLayout.WEST, tglbtnDelete, 24, SpringLayout.WEST, frame.getContentPane());
		springLayout.putConstraint(SpringLayout.SOUTH, tglbtnDelete, 0, SpringLayout.SOUTH, ftf);
		frame.getContentPane().add(tglbtnDelete);
		
		JToggleButton tglbtnBack = new JToggleButton("back");
		tglbtnBack.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					DEMO window = new DEMO();
					(window).getfframe().setVisible(true);
				} catch (Exception es) {
					es.printStackTrace();
				}
				
			}
		});
		springLayout.putConstraint(SpringLayout.SOUTH, tglbtnBack, 0, SpringLayout.SOUTH, ftf);
		springLayout.putConstraint(SpringLayout.EAST, tglbtnBack, -6, SpringLayout.WEST, ftf);
		frame.getContentPane().add(tglbtnBack);
	}

}
