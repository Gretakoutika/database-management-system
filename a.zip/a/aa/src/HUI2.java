import java.awt.EventQueue;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;

import javax.swing.JFrame;
import java.awt.CardLayout;
import javax.swing.SpringLayout;
import java.awt.SystemColor;
import java.awt.TextArea;
import java.awt.List;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.JToggleButton;

public class HUI2 {
	Connection connection;
	Statement statement;
	ResultSet rs;
	private List list = new List(10);

	private JFrame frame;
	private JTextField t1;
	private JTextField t2;
	private JTextField t3;
	private JTextField t4;
	private JTextField t5;
	private TextArea ftf;
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					HUI2 window = new HUI2();
					window.getFrame().setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public HUI2() {
		try 
		{
			Class.forName("oracle.jdbc.driver.OracleDriver");
		} 
		catch (Exception e) 
		{
			System.err.println("Unable to find and load driver");
			System.exit(1);
		}
		connectToDB();
		initialize();
	}
	public void connectToDB() 
    {
		try 
		{
		  connection = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","greta","GRETA0910");
		  statement = connection.createStatement();

		} 
		catch (SQLException connectException) 
		{
		  System.out.println(connectException.getMessage());
		  System.out.println(connectException.getSQLState());
		  System.out.println(connectException.getErrorCode());
		  System.exit(1);
		}
    }
	private void loadList() 
	{	   
		try 
		{
		  rs = statement.executeQuery("SELECT HID FROM hotels");
		  while (rs.next()) 
		  {
			list.add(rs.getString("HID"));
		  }
		} 
		catch (SQLException e) 
		{ 
		  ftf.append(e.getMessage());
		}
	}
	
	private void initialize() {
		setFrame(new JFrame());
		getFrame().getContentPane().setBackground(SystemColor.activeCaption);
		getFrame().setBounds(100, 100, 450, 300);
		getFrame().setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		SpringLayout springLayout = new SpringLayout();
		getFrame().getContentPane().setLayout(springLayout);
		
		TextArea ftf = new TextArea();
		springLayout.putConstraint(SpringLayout.NORTH, ftf, -71, SpringLayout.SOUTH, getFrame().getContentPane());
		springLayout.putConstraint(SpringLayout.WEST, ftf, 180, SpringLayout.WEST, getFrame().getContentPane());
		springLayout.putConstraint(SpringLayout.SOUTH, ftf, -10, SpringLayout.SOUTH, getFrame().getContentPane());
		springLayout.putConstraint(SpringLayout.EAST, ftf, -10, SpringLayout.EAST, getFrame().getContentPane());
		getFrame().getContentPane().add(ftf);
		
		
		list.addItemListener(new ItemListener() {
			public void itemStateChanged(ItemEvent arg0) {
				try 
				{
					rs = statement.executeQuery("SELECT * FROM hotels where HID ="+list.getSelectedItem());
					rs.next();
					t1.setText(rs.getString("HID"));
					t2.setText(rs.getString("NAME"));
					t3.setText(rs.getString("CONTACT"));
					t4.setText(rs.getString("EMAIL_ID"));
					t5.setText(rs.getString("ADDRESS"));
				} 
				catch (SQLException selectException) 
				{
					ftf.append(selectException.getMessage());
				}
			}
		});
		
		
		springLayout.putConstraint(SpringLayout.NORTH, list, 10, SpringLayout.NORTH, getFrame().getContentPane());
		springLayout.putConstraint(SpringLayout.WEST, list, 10, SpringLayout.WEST, getFrame().getContentPane());
		loadList();
		getFrame().getContentPane().add(list);
		
		JLabel lblHotelId = new JLabel("Hotel Id:");
		springLayout.putConstraint(SpringLayout.NORTH, lblHotelId, 0, SpringLayout.NORTH, list);
		springLayout.putConstraint(SpringLayout.WEST, lblHotelId, 32, SpringLayout.EAST, list);
		getFrame().getContentPane().add(lblHotelId);
		
		JLabel lblHotelName = new JLabel("Hotel Name:");
		springLayout.putConstraint(SpringLayout.WEST, lblHotelName, 0, SpringLayout.WEST, ftf);
		getFrame().getContentPane().add(lblHotelName);
		
		JLabel lblContact = new JLabel("Contact:");
		springLayout.putConstraint(SpringLayout.NORTH, lblContact, 80, SpringLayout.NORTH, getFrame().getContentPane());
		springLayout.putConstraint(SpringLayout.SOUTH, lblHotelName, -14, SpringLayout.NORTH, lblContact);
		springLayout.putConstraint(SpringLayout.WEST, lblContact, 0, SpringLayout.WEST, lblHotelId);
		getFrame().getContentPane().add(lblContact);
		
		JLabel lblNewLabel = new JLabel("Email id:");
		springLayout.putConstraint(SpringLayout.NORTH, lblNewLabel, 10, SpringLayout.SOUTH, lblContact);
		springLayout.putConstraint(SpringLayout.WEST, lblNewLabel, 0, SpringLayout.WEST, lblHotelId);
		getFrame().getContentPane().add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("Address:");
		springLayout.putConstraint(SpringLayout.NORTH, lblNewLabel_1, 6, SpringLayout.SOUTH, lblNewLabel);
		springLayout.putConstraint(SpringLayout.WEST, lblNewLabel_1, 0, SpringLayout.WEST, lblHotelId);
		getFrame().getContentPane().add(lblNewLabel_1);
		
		t1 = new JTextField();
		springLayout.putConstraint(SpringLayout.NORTH, t1, 0, SpringLayout.NORTH, list);
		springLayout.putConstraint(SpringLayout.EAST, t1, 0, SpringLayout.EAST, ftf);
		getFrame().getContentPane().add(t1);
		t1.setColumns(10);
		
		t2 = new JTextField();
		springLayout.putConstraint(SpringLayout.NORTH, t2, 0, SpringLayout.NORTH, lblHotelName);
		springLayout.putConstraint(SpringLayout.EAST, t2, 0, SpringLayout.EAST, ftf);
		getFrame().getContentPane().add(t2);
		t2.setColumns(10);
		
		t3 = new JTextField();
		springLayout.putConstraint(SpringLayout.NORTH, t3, 0, SpringLayout.NORTH, lblContact);
		springLayout.putConstraint(SpringLayout.EAST, t3, 0, SpringLayout.EAST, ftf);
		getFrame().getContentPane().add(t3);
		t3.setColumns(10);
		
		t4 = new JTextField();
		springLayout.putConstraint(SpringLayout.NORTH, t4, 0, SpringLayout.NORTH, lblNewLabel);
		springLayout.putConstraint(SpringLayout.EAST, t4, 0, SpringLayout.EAST, ftf);
		getFrame().getContentPane().add(t4);
		t4.setColumns(10);
		
		t5 = new JTextField();
		springLayout.putConstraint(SpringLayout.WEST, t5, 0, SpringLayout.WEST, t1);
		springLayout.putConstraint(SpringLayout.SOUTH, t5, -6, SpringLayout.NORTH, ftf);
		getFrame().getContentPane().add(t5);
		t5.setColumns(10);
		
		JToggleButton tglbtnUpdate = new JToggleButton("Update");
		tglbtnUpdate.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {

				try 
				{
					Statement statement = connection.createStatement();
					int i = statement.executeUpdate("UPDATE hotels"
					+ "SET name='" + t2.getText() + "',"
					+ "contact=" +"'"+ t3.getText() + "',"
					+ "email_id=" + "'" + t4.getText() + "',"
					+ "address=" +"'" +t5.getText() + " ' WHERE hid= "
					+ list.getSelectedItem());
					ftf.append("\nUpdated " + i + " rows successfully");
					list.removeAll();
					loadList();
				} 
				catch (SQLException insertException) 
				{
					ftf.append(insertException.getMessage());
				}
			}
			
		});
		getFrame().getContentPane().add(tglbtnUpdate);
		
		JToggleButton tglbtnBack = new JToggleButton("Back");
		tglbtnBack.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				try {
					DEMO window = new DEMO();
					(window).getfframe().setVisible(true);
				} catch (Exception es) {
					es.printStackTrace();
				}
			}
		});
		springLayout.putConstraint(SpringLayout.NORTH, tglbtnUpdate, 0, SpringLayout.NORTH, tglbtnBack);
		springLayout.putConstraint(SpringLayout.EAST, tglbtnUpdate, -6, SpringLayout.WEST, tglbtnBack);
		springLayout.putConstraint(SpringLayout.SOUTH, tglbtnBack, -10, SpringLayout.SOUTH, getFrame().getContentPane());
		springLayout.putConstraint(SpringLayout.EAST, tglbtnBack, -6, SpringLayout.WEST, ftf);
		getFrame().getContentPane().add(tglbtnBack);
	}

	public JFrame getFrame() {
		return frame;
	}

	public void setFrame(JFrame frame) {
		this.frame = frame;
	}

}
