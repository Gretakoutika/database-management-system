import java.awt.EventQueue;

import javax.swing.JFrame;
import java.awt.CardLayout;
import java.awt.GridLayout;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
import java.awt.Color;
import javax.swing.SpringLayout;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.JToggleButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.TextArea;

public class SUI1 {

	private JFrame frame;
	private JTextField t1;
	private JTextField t2;
	private JTextField t3;
	private JTextField t4;
	Connection connection;
	Statement statement;
	private JTextField ftf;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					SUI1 window = new SUI1();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public SUI1() {
		try 
		{
		  connection = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","greta","GRETA0910");
		  statement = connection.createStatement();

		} 
		catch (SQLException connectException) 
		{
		  System.out.println(connectException.getMessage());
		  System.out.println(connectException.getSQLState());
		  System.out.println(connectException.getErrorCode());
		  System.exit(1);
		}
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.getContentPane().setBackground(new Color(176, 196, 222));
		SpringLayout springLayout = new SpringLayout();
		frame.getContentPane().setLayout(springLayout);
		
		JLabel lblSid = new JLabel("SID:");
		frame.getContentPane().add(lblSid);
		
		JLabel lblNewLabel = new JLabel("ROOM COST:");
		springLayout.putConstraint(SpringLayout.SOUTH, lblSid, -23, SpringLayout.NORTH, lblNewLabel);
		springLayout.putConstraint(SpringLayout.WEST, lblNewLabel, 0, SpringLayout.WEST, lblSid);
		frame.getContentPane().add(lblNewLabel);
		
		JLabel lblFood = new JLabel("FOOD:");
		springLayout.putConstraint(SpringLayout.NORTH, lblFood, 98, SpringLayout.NORTH, frame.getContentPane());
		springLayout.putConstraint(SpringLayout.SOUTH, lblNewLabel, -9, SpringLayout.NORTH, lblFood);
		springLayout.putConstraint(SpringLayout.WEST, lblFood, 0, SpringLayout.WEST, lblSid);
		frame.getContentPane().add(lblFood);
		
		JLabel lblMaintenance = new JLabel("MAINTENANCE:");
		springLayout.putConstraint(SpringLayout.NORTH, lblMaintenance, 16, SpringLayout.SOUTH, lblFood);
		springLayout.putConstraint(SpringLayout.WEST, lblSid, 0, SpringLayout.WEST, lblMaintenance);
		springLayout.putConstraint(SpringLayout.WEST, lblMaintenance, 148, SpringLayout.WEST, frame.getContentPane());
		frame.getContentPane().add(lblMaintenance);
		
		t1 = new JTextField();
		springLayout.putConstraint(SpringLayout.NORTH, t1, -3, SpringLayout.NORTH, lblSid);
		frame.getContentPane().add(t1);
		t1.setColumns(10);
		
		t2 = new JTextField();
		springLayout.putConstraint(SpringLayout.WEST, t1, 0, SpringLayout.WEST, t2);
		springLayout.putConstraint(SpringLayout.WEST, t2, 270, SpringLayout.WEST, frame.getContentPane());
		frame.getContentPane().add(t2);
		t2.setColumns(10);
		
		t3 = new JTextField();
		springLayout.putConstraint(SpringLayout.SOUTH, t2, -6, SpringLayout.NORTH, t3);
		springLayout.putConstraint(SpringLayout.NORTH, t3, -3, SpringLayout.NORTH, lblFood);
		springLayout.putConstraint(SpringLayout.EAST, t3, 0, SpringLayout.EAST, t1);
		frame.getContentPane().add(t3);
		t3.setColumns(10);
		
		t4 = new JTextField();
		springLayout.putConstraint(SpringLayout.NORTH, t4, -3, SpringLayout.NORTH, lblMaintenance);
		springLayout.putConstraint(SpringLayout.EAST, t4, 0, SpringLayout.EAST, t1);
		frame.getContentPane().add(t4);
		t4.setColumns(10);
		
		JToggleButton tglbtnInsert = new JToggleButton("INSERT");
		tglbtnInsert.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try 
				{
				  Statement statement = connection.createStatement();				  
				  String query= "INSERT INTO SERVICES VALUES(" + t1.getText() + "," + "'" + t2.getText() + "','" +t3.getText() + "','"+ t4.getText()+"')";
				  int i = statement.executeUpdate(query);
				  ftf.setText("\nInserted " + i + " rows successfully");
				} 
				catch (SQLException insertException) 
				{
				  ftf.setText(insertException.getMessage());
				}
			}
		});
		springLayout.putConstraint(SpringLayout.WEST, tglbtnInsert, 55, SpringLayout.WEST, frame.getContentPane());
		springLayout.putConstraint(SpringLayout.SOUTH, tglbtnInsert, -28, SpringLayout.SOUTH, frame.getContentPane());
		frame.getContentPane().add(tglbtnInsert);
		
		JToggleButton tglbtnBack = new JToggleButton("Back");
		springLayout.putConstraint(SpringLayout.NORTH, tglbtnBack, 0, SpringLayout.NORTH, tglbtnInsert);
		springLayout.putConstraint(SpringLayout.WEST, tglbtnBack, 8, SpringLayout.EAST, tglbtnInsert);
		frame.getContentPane().add(tglbtnBack);
		
		ftf = new JTextField();
		springLayout.putConstraint(SpringLayout.NORTH, ftf, -17, SpringLayout.NORTH, tglbtnInsert);
		springLayout.putConstraint(SpringLayout.SOUTH, ftf, -12, SpringLayout.SOUTH, frame.getContentPane());
		springLayout.putConstraint(SpringLayout.EAST, ftf, -50, SpringLayout.EAST, frame.getContentPane());
		frame.getContentPane().add(ftf);
		ftf.setColumns(10);
		frame.setBounds(100, 100, 450, 300);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}

}
