import java.awt.EventQueue;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;

import javax.swing.JFrame;
import java.awt.CardLayout;
import javax.swing.SpringLayout;
import java.awt.SystemColor;
import java.awt.TextArea;
import java.sql.DriverManager;
import java.sql.SQLException;

import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.JToggleButton;

public class HUI1 {
	Connection connection;
	Statement statement;
	String query;
	
	private JFrame frame;
	private JTextField t1;
	private JTextField t2;
	private JTextField t3;
	private JTextField t5;
	private JTextField t4;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					HUI1 window = new HUI1();
					window.getFrame().setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public HUI1() {
		try 
		{
			Class.forName("oracle.jdbc.driver.OracleDriver");
		} 
		catch (Exception e) 
		{
			System.err.println("Unable to find and load driver");
			System.exit(1);
		}
		connecttoDB();
	
		
		initialize();
	}
	public void connecttoDB()
	{
		try 
		{
		  connection = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","greta","GRETA0910");
		  statement = connection.createStatement();

		} 
		catch (SQLException connectException) 
		{
		  System.out.println(connectException.getMessage());
		  System.out.println(connectException.getSQLState());
		  System.out.println(connectException.getErrorCode());
		  System.exit(1);
		}
		
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		setFrame(new JFrame());
		getFrame().getContentPane().setBackground(SystemColor.activeCaption);
		getFrame().setBounds(100, 100, 450, 300);
		getFrame().setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		SpringLayout springLayout = new SpringLayout();
		getFrame().getContentPane().setLayout(springLayout);
		
		TextArea ftf = new TextArea();
		springLayout.putConstraint(SpringLayout.NORTH, ftf, 168, SpringLayout.NORTH, getFrame().getContentPane());
		springLayout.putConstraint(SpringLayout.WEST, ftf, 221, SpringLayout.WEST, getFrame().getContentPane());
		springLayout.putConstraint(SpringLayout.SOUTH, ftf, -10, SpringLayout.SOUTH, getFrame().getContentPane());
		springLayout.putConstraint(SpringLayout.EAST, ftf, -48, SpringLayout.EAST, getFrame().getContentPane());
		getFrame().getContentPane().add(ftf);
		
		JLabel hid = new JLabel("Hotel id:");
		getFrame().getContentPane().add(hid);
		
		JLabel lblHotelName_1 = new JLabel("Hotel name:");
		springLayout.putConstraint(SpringLayout.WEST, lblHotelName_1, 0, SpringLayout.WEST, hid);
		getFrame().getContentPane().add(lblHotelName_1);
		
		JLabel lblContact = new JLabel("Contact:");
		springLayout.putConstraint(SpringLayout.SOUTH, lblHotelName_1, -6, SpringLayout.NORTH, lblContact);
		springLayout.putConstraint(SpringLayout.EAST, lblContact, 0, SpringLayout.EAST, hid);
		getFrame().getContentPane().add(lblContact);
		
		JLabel lblEmailid = new JLabel("Email_id");
		springLayout.putConstraint(SpringLayout.NORTH, lblEmailid, 101, SpringLayout.NORTH, getFrame().getContentPane());
		springLayout.putConstraint(SpringLayout.SOUTH, lblContact, -5, SpringLayout.NORTH, lblEmailid);
		springLayout.putConstraint(SpringLayout.WEST, lblEmailid, 0, SpringLayout.WEST, hid);
		getFrame().getContentPane().add(lblEmailid);
		
		JLabel lblAddress = new JLabel("Address:");
		springLayout.putConstraint(SpringLayout.WEST, lblAddress, 0, SpringLayout.WEST, hid);
		springLayout.putConstraint(SpringLayout.SOUTH, lblAddress, -6, SpringLayout.NORTH, ftf);
		getFrame().getContentPane().add(lblAddress);
		
		t1 = new JTextField();
		springLayout.putConstraint(SpringLayout.WEST, t1, 265, SpringLayout.WEST, getFrame().getContentPane());
		springLayout.putConstraint(SpringLayout.SOUTH, t1, -124, SpringLayout.NORTH, ftf);
		springLayout.putConstraint(SpringLayout.NORTH, hid, 3, SpringLayout.NORTH, t1);
		springLayout.putConstraint(SpringLayout.EAST, hid, -26, SpringLayout.WEST, t1);
		getFrame().getContentPane().add(t1);
		t1.setColumns(10);
		
		t2 = new JTextField();
		springLayout.putConstraint(SpringLayout.NORTH, t2, -3, SpringLayout.NORTH, lblHotelName_1);
		springLayout.putConstraint(SpringLayout.WEST, t2, 0, SpringLayout.WEST, t1);
		getFrame().getContentPane().add(t2);
		t2.setColumns(10);
		
		t3 = new JTextField();
		springLayout.putConstraint(SpringLayout.NORTH, t3, 6, SpringLayout.SOUTH, lblHotelName_1);
		springLayout.putConstraint(SpringLayout.WEST, t3, 0, SpringLayout.WEST, t1);
		getFrame().getContentPane().add(t3);
		t3.setColumns(10);
		
		t5 = new JTextField();
		springLayout.putConstraint(SpringLayout.SOUTH, t5, -6, SpringLayout.NORTH, ftf);
		springLayout.putConstraint(SpringLayout.EAST, t5, 0, SpringLayout.EAST, t1);
		getFrame().getContentPane().add(t5);
		t5.setColumns(10);
		
		t4 = new JTextField();
		springLayout.putConstraint(SpringLayout.SOUTH, t4, -6, SpringLayout.NORTH, t5);
		springLayout.putConstraint(SpringLayout.EAST, t4, 0, SpringLayout.EAST, t1);
		getFrame().getContentPane().add(t4);
		t4.setColumns(10);
		
		JToggleButton tglbtnInsertHotel = new JToggleButton("Insert Hotel");
		tglbtnInsertHotel.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
			Statement statement;
			try {
				
				statement = connection.createStatement();
				query = "INSERT INTO HOTELS VALUES("+t1.getText()+","+"'"+t2.getText()+"','"+t3.getText()+"','"+t4.getText()+"','"+t5.getText()+"')";
				
				int i=statement.executeUpdate(query);
				ftf.append("\n Inserted "+i+"rows succesfully");
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				ftf.append(e.getMessage());
			}
			
			}
		});
		springLayout.putConstraint(SpringLayout.WEST, tglbtnInsertHotel, 10, SpringLayout.WEST, getFrame().getContentPane());
		springLayout.putConstraint(SpringLayout.SOUTH, tglbtnInsertHotel, -59, SpringLayout.SOUTH, getFrame().getContentPane());
		getFrame().getContentPane().add(tglbtnInsertHotel);
		
		JToggleButton tglbtnBack = new JToggleButton("Back");
		tglbtnBack.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				try {
					DEMO window = new DEMO();
					(window).getfframe().setVisible(true);
				} catch (Exception es) {
					es.printStackTrace();
				}
			}
		});
		springLayout.putConstraint(SpringLayout.NORTH, tglbtnBack, 5, SpringLayout.SOUTH, tglbtnInsertHotel);
		springLayout.putConstraint(SpringLayout.WEST, tglbtnBack, 32, SpringLayout.WEST, getFrame().getContentPane());
		getFrame().getContentPane().add(tglbtnBack);
	}

	public JFrame getFrame() {
		return frame;
	}

	public void setFrame(JFrame frame) {
		this.frame = frame;
	}
}
