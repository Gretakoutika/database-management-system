import java.awt.EventQueue;

import javax.swing.JFrame;
import java.awt.CardLayout;
import javax.swing.SpringLayout;
import java.awt.Color;
import java.awt.TextArea;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.awt.List;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.JToggleButton;
import java.awt.event.ItemListener;
import java.awt.event.ItemEvent;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class FUI3 {

	private JFrame frame;
	private JTextField t1;
	private JTextField t2;
	private JTextField t4;
	TextArea ftf;
	List list = new List(10);
	private JTextField t3;
	Connection connection;
	Statement statement;
	ResultSet rs;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					FUI3 window = new FUI3();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public FUI3() {
		try 
		{
			Class.forName("oracle.jdbc.driver.OracleDriver");
		} 
		catch (Exception e) 
		{
			System.err.println("Unable to find and load driver");
			System.exit(1);
		}
		connectToDB();
		initialize();
	}

	public void connectToDB() 
    {
		try 
		{
		  connection = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","greta","GRETA0910");
		  statement = connection.createStatement();

		} 
		catch (SQLException connectException) 
		{
		  System.out.println(connectException.getMessage());
		  System.out.println(connectException.getSQLState());
		  System.out.println(connectException.getErrorCode());
		  System.exit(1);
		}
    }
	
	private void loadList() 
	{	   
		try 
		{
		  rs = statement.executeQuery("SELECT * FROM FEEDBACK");
		  while (rs.next()) 
		  {
			list.add(rs.getString("FID"));
		  }
		} 
		catch (SQLException e) 
		{ 
		  ftf.append(e.getMessage());
		}
	}
	

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.getContentPane().setBackground(new Color(255, 222, 173));
		frame.setBounds(100, 100, 450, 300);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		SpringLayout springLayout = new SpringLayout();
		frame.getContentPane().setLayout(springLayout);
		
		TextArea ftf = new TextArea();
		springLayout.putConstraint(SpringLayout.NORTH, ftf, -71, SpringLayout.SOUTH, frame.getContentPane());
		springLayout.putConstraint(SpringLayout.WEST, ftf, 226, SpringLayout.WEST, frame.getContentPane());
		springLayout.putConstraint(SpringLayout.SOUTH, ftf, -10, SpringLayout.SOUTH, frame.getContentPane());
		springLayout.putConstraint(SpringLayout.EAST, ftf, -10, SpringLayout.EAST, frame.getContentPane());
		frame.getContentPane().add(ftf);
		loadList();
		springLayout.putConstraint(SpringLayout.NORTH, list, 10, SpringLayout.NORTH, frame.getContentPane());
		springLayout.putConstraint(SpringLayout.WEST, list, 0, SpringLayout.WEST, frame.getContentPane());
		list.addItemListener(new ItemListener() {
			public void itemStateChanged(ItemEvent arg0) {
				try 
				{
					rs = statement.executeQuery("SELECT * FROM feedback");
					while (rs.next()) 
					{
						if (rs.getString("FID").equals(list.getSelectedItem()))
						break;
					}
					if (!rs.isAfterLast()) 
					{
						t1.setText(rs.getString("FID"));
						t2.setText(rs.getString("SUGGESTIONS"));
						t3.setText(rs.getString("COMPLAINTS"));
						t4.setText(rs.getString("RATING"));
					}
				} 
				catch (SQLException selectException) 
				{
					ftf.append(selectException.getMessage());
				}
				
				
			}
		});
		frame.getContentPane().add(list);
		
		JLabel lblFid = new JLabel("FID:");
		springLayout.putConstraint(SpringLayout.NORTH, lblFid, 0, SpringLayout.NORTH, list);
		springLayout.putConstraint(SpringLayout.WEST, lblFid, 6, SpringLayout.EAST, list);
		frame.getContentPane().add(lblFid);
		
		JLabel lblSuggestions = new JLabel("SUGGESTIONS:");
		springLayout.putConstraint(SpringLayout.NORTH, lblSuggestions, 6, SpringLayout.SOUTH, lblFid);
		springLayout.putConstraint(SpringLayout.WEST, lblSuggestions, 2, SpringLayout.EAST, list);
		frame.getContentPane().add(lblSuggestions);
		
		JLabel lblComplaints = new JLabel("COMPLAINTS:");
		springLayout.putConstraint(SpringLayout.WEST, lblComplaints, 0, SpringLayout.EAST, list);
		springLayout.putConstraint(SpringLayout.SOUTH, lblComplaints, -134, SpringLayout.SOUTH, frame.getContentPane());
		frame.getContentPane().add(lblComplaints);
		
		JLabel lblRating = new JLabel("RATING:");
		springLayout.putConstraint(SpringLayout.NORTH, lblRating, 31, SpringLayout.SOUTH, lblComplaints);
		springLayout.putConstraint(SpringLayout.WEST, lblRating, 4, SpringLayout.EAST, list);
		frame.getContentPane().add(lblRating);
		
		t1 = new JTextField();
		springLayout.putConstraint(SpringLayout.NORTH, t1, -3, SpringLayout.NORTH, lblFid);
		springLayout.putConstraint(SpringLayout.EAST, t1, -10, SpringLayout.EAST, frame.getContentPane());
		frame.getContentPane().add(t1);
		t1.setColumns(10);
		
		t2 = new JTextField();
		springLayout.putConstraint(SpringLayout.NORTH, t2, 0, SpringLayout.NORTH, lblSuggestions);
		springLayout.putConstraint(SpringLayout.WEST, t2, 0, SpringLayout.WEST, t1);
		frame.getContentPane().add(t2);
		t2.setColumns(10);
		
		t4 = new JTextField();
		springLayout.putConstraint(SpringLayout.WEST, t4, 0, SpringLayout.WEST, t1);
		frame.getContentPane().add(t4);
		t4.setColumns(10);
		
		JToggleButton tglbtnDelete = new JToggleButton("DELETE");
		tglbtnDelete.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try 
				{
					Statement statement = connection.createStatement();
					int i = statement.executeUpdate("DELETE FROM FEEDBACK WHERE FID = "
							+ list.getSelectedItem());
					ftf.append("\nDeleted " + i + " rows successfully");
					t1.setText(null);
					t2.setText(null);
					t3.setText(null);
					t4.setText(null);
					list.removeAll();
					loadList();
				} 
				catch (SQLException insertException) 
				{
					ftf.append(insertException.getMessage());
				}
			}
		});
		springLayout.putConstraint(SpringLayout.WEST, tglbtnDelete, 10, SpringLayout.WEST, frame.getContentPane());
		frame.getContentPane().add(tglbtnDelete);
		
		JToggleButton tglbtnBack = new JToggleButton("BACK");
		tglbtnBack.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					DEMO window = new DEMO();
					(window).getfframe().setVisible(true);
				} catch (Exception es) {
					es.printStackTrace();
				}
				
			}
		});
		springLayout.putConstraint(SpringLayout.NORTH, tglbtnDelete, 0, SpringLayout.NORTH, tglbtnBack);
		springLayout.putConstraint(SpringLayout.SOUTH, tglbtnBack, -10, SpringLayout.SOUTH, frame.getContentPane());
		springLayout.putConstraint(SpringLayout.EAST, tglbtnBack, -17, SpringLayout.WEST, ftf);
		frame.getContentPane().add(tglbtnBack);
		
		t3 = new JTextField();
		springLayout.putConstraint(SpringLayout.NORTH, t4, 17, SpringLayout.SOUTH, t3);
		springLayout.putConstraint(SpringLayout.SOUTH, t3, 0, SpringLayout.SOUTH, lblComplaints);
		springLayout.putConstraint(SpringLayout.EAST, t3, 0, SpringLayout.EAST, ftf);
		frame.getContentPane().add(t3);
		t3.setColumns(10);
	}

}
