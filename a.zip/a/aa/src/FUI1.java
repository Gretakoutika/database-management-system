import java.awt.EventQueue;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;

import javax.swing.JFrame;
import javax.swing.SpringLayout;
import java.awt.Color;
import java.awt.TextArea;

import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.JToggleButton;

public class FUI1 {

	private JFrame frame;
	private JTextField t1;
	private JTextField t2;
	private JTextField t3;
	private JTextField t4;
	Connection connection;
	Statement statement;
	ResultSet rs;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					FUI1 window = new FUI1();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public FUI1() {
		try 
		{
			Class.forName("oracle.jdbc.driver.OracleDriver");
		} 
		catch (Exception e) 
		{
			System.err.println("Unable to find and load driver");
			System.exit(1);
		}
		connectToDB();
		initialize();
	}

	private void connectToDB() {
		// TODO Auto-generated method stub
		try 
		{
		  connection = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","greta","GRETA0910");
		  statement = connection.createStatement();

		} 
		catch (SQLException connectException) 
		{
		  System.out.println(connectException.getMessage());
		  System.out.println(connectException.getSQLState());
		  System.out.println(connectException.getErrorCode());
		  System.exit(1);
		}
    }
	

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.getContentPane().setBackground(new Color(245, 222, 179));
		frame.setBounds(100, 100, 450, 300);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		SpringLayout springLayout = new SpringLayout();
		frame.getContentPane().setLayout(springLayout);
		
		TextArea ftf = new TextArea();
		springLayout.putConstraint(SpringLayout.NORTH, ftf, -83, SpringLayout.SOUTH, frame.getContentPane());
		springLayout.putConstraint(SpringLayout.WEST, ftf, 208, SpringLayout.WEST, frame.getContentPane());
		springLayout.putConstraint(SpringLayout.SOUTH, ftf, -10, SpringLayout.SOUTH, frame.getContentPane());
		springLayout.putConstraint(SpringLayout.EAST, ftf, -27, SpringLayout.EAST, frame.getContentPane());
		frame.getContentPane().add(ftf);
		
		JLabel lblFid = new JLabel("FID:");
		frame.getContentPane().add(lblFid);
		
		JLabel lblSuggestions = new JLabel("SUGGESTIONS:");
		springLayout.putConstraint(SpringLayout.SOUTH, lblSuggestions, -165, SpringLayout.SOUTH, frame.getContentPane());
		springLayout.putConstraint(SpringLayout.WEST, lblFid, 0, SpringLayout.WEST, lblSuggestions);
		springLayout.putConstraint(SpringLayout.SOUTH, lblFid, -6, SpringLayout.NORTH, lblSuggestions);
		frame.getContentPane().add(lblSuggestions);
		
		JLabel lblComplaints = new JLabel("COMPLAINTS:");
		springLayout.putConstraint(SpringLayout.NORTH, lblComplaints, 6, SpringLayout.SOUTH, lblSuggestions);
		springLayout.putConstraint(SpringLayout.WEST, lblComplaints, 0, SpringLayout.WEST, lblFid);
		frame.getContentPane().add(lblComplaints);
		
		JLabel lblRating = new JLabel("RATING:");
		springLayout.putConstraint(SpringLayout.NORTH, lblRating, 6, SpringLayout.SOUTH, lblComplaints);
		springLayout.putConstraint(SpringLayout.WEST, lblRating, 0, SpringLayout.WEST, lblFid);
		frame.getContentPane().add(lblRating);
		
		t1 = new JTextField();
		springLayout.putConstraint(SpringLayout.NORTH, t1, -3, SpringLayout.NORTH, lblFid);
		frame.getContentPane().add(t1);
		t1.setColumns(10);
		
		t2 = new JTextField();
		springLayout.putConstraint(SpringLayout.NORTH, t2, 3, SpringLayout.SOUTH, t1);
		springLayout.putConstraint(SpringLayout.EAST, t2, -37, SpringLayout.EAST, frame.getContentPane());
		springLayout.putConstraint(SpringLayout.WEST, t1, 0, SpringLayout.WEST, t2);
		springLayout.putConstraint(SpringLayout.EAST, lblSuggestions, -5, SpringLayout.WEST, t2);
		frame.getContentPane().add(t2);
		t2.setColumns(10);
		
		t3 = new JTextField();
		springLayout.putConstraint(SpringLayout.EAST, t3, 0, SpringLayout.EAST, t2);
		frame.getContentPane().add(t3);
		t3.setColumns(10);
		
		t4 = new JTextField();
		springLayout.putConstraint(SpringLayout.NORTH, t4, 119, SpringLayout.NORTH, frame.getContentPane());
		springLayout.putConstraint(SpringLayout.SOUTH, t3, -6, SpringLayout.NORTH, t4);
		springLayout.putConstraint(SpringLayout.WEST, t4, 0, SpringLayout.WEST, t2);
		frame.getContentPane().add(t4);
		t4.setColumns(10);
		
		JToggleButton tglbtnInsert = new JToggleButton("INSERT");
		tglbtnInsert.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try 
				{
				  Statement statement = connection.createStatement();				  
				  String query= "INSERT INTO FEEDBACK VALUES(" + t1.getText() + "," + "'" + t2.getText() + "','" +t3.getText() + "',"+ t4.getText()+")";
				  int i = statement.executeUpdate(query);
				  ftf.append("\nInserted " + i + " rows successfully");
				} 
				catch (SQLException insertException) 
				{
				  ftf.append(insertException.getMessage());
				}
				
			}
		});
		springLayout.putConstraint(SpringLayout.WEST, tglbtnInsert, 10, SpringLayout.WEST, frame.getContentPane());
		frame.getContentPane().add(tglbtnInsert);
		
		JToggleButton tglbtnBack = new JToggleButton("BACK");
		tglbtnBack.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					DEMO window = new DEMO();
					(window).getfframe().setVisible(true);
				} catch (Exception es) {
					es.printStackTrace();
				}
				
			}
		});
		springLayout.putConstraint(SpringLayout.NORTH, tglbtnInsert, 0, SpringLayout.NORTH, tglbtnBack);
		springLayout.putConstraint(SpringLayout.SOUTH, tglbtnBack, -30, SpringLayout.SOUTH, frame.getContentPane());
		springLayout.putConstraint(SpringLayout.EAST, tglbtnBack, -17, SpringLayout.WEST, ftf);
		frame.getContentPane().add(tglbtnBack);
		
	}

}
