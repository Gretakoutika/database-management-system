import java.awt.EventQueue;

import java.awt.*;
import java.awt.event.*;
import java.sql.*;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

import javax.swing.JFrame;
import java.awt.CardLayout;
import javax.swing.SpringLayout;
import java.awt.Color;
import java.awt.TextArea;
import java.awt.List;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.JToggleButton;

public class PRUI3 {

	List list = new List(10);
	TextArea ftf;
	private JFrame frame;
	private JTextField t1;
	private JTextField t2;
	private JTextField t3;
	Connection connection;
	Statement statement;
	ResultSet rs;
	private JTextField T3;


	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					PRUI3 window = new PRUI3();
					window.getFrame().setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}
	public PRUI3() {
		try 
		{
			Class.forName("oracle.jdbc.driver.OracleDriver");
		} 
		catch (Exception e) 
		{
			System.err.println("Unable to find and load driver");
			System.exit(1);
		}
		connectToDB();
		initialize();
		
	}
	private void connectToDB() {
		// TODO Auto-generated method stub
		try 
		{
		  connection = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","greta","GRETA0910");
		  statement = connection.createStatement();

		} 
		catch (SQLException connectException) 
		{
		  System.out.println(connectException.getMessage());
		  System.out.println(connectException.getSQLState());
		  System.out.println(connectException.getErrorCode());
		  System.exit(1);
		}
    }
	private void loadList() 
	{	   
		try 
		{
		  rs = statement.executeQuery("SELECT HID FROM PROVIDES");
		  while (rs.next()) 
		  {
			list.add(rs.getString("HID"));
		  }
		} 
		catch (SQLException e) 
		{ 
		  ftf.append(e.getMessage());
		}
	}
	
	

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		setFrame(new JFrame());
		getFrame().getContentPane().setBackground(new Color(255, 228, 181));
		getFrame().setBounds(100, 100, 450, 300);
		getFrame().setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		SpringLayout springLayout = new SpringLayout();
		getFrame().getContentPane().setLayout(springLayout);
		
		TextArea ftf = new TextArea();
		springLayout.putConstraint(SpringLayout.NORTH, ftf, -81, SpringLayout.SOUTH, getFrame().getContentPane());
		springLayout.putConstraint(SpringLayout.WEST, ftf, 183, SpringLayout.WEST, getFrame().getContentPane());
		springLayout.putConstraint(SpringLayout.SOUTH, ftf, -10, SpringLayout.SOUTH, getFrame().getContentPane());
		springLayout.putConstraint(SpringLayout.EAST, ftf, -21, SpringLayout.EAST, getFrame().getContentPane());
		getFrame().getContentPane().add(ftf);
		loadList();
		list.addItemListener(new ItemListener() {
			public void itemStateChanged(ItemEvent arg0) {
				try 
				{
					rs = statement.executeQuery("SELECT * FROM PROVIDES where HID ="+list.getSelectedItem());
					rs.next();
					t1.setText(rs.getString("HID"));
					t2.setText(rs.getString("SID"));
					T3.setText(rs.getString("SINCE"));
					
				
				} 
				catch (SQLException selectException) 
				{
					ftf.append(selectException.getMessage());
				}
			}
		});
		getFrame().getContentPane().add(list);
		
		JLabel lblFid = new JLabel("HID:");
		springLayout.putConstraint(SpringLayout.WEST, lblFid, 160, SpringLayout.WEST, getFrame().getContentPane());
		springLayout.putConstraint(SpringLayout.EAST, list, -6, SpringLayout.WEST, lblFid);
		springLayout.putConstraint(SpringLayout.NORTH, lblFid, 26, SpringLayout.NORTH, getFrame().getContentPane());
		getFrame().getContentPane().add(lblFid);
		
		JLabel lblSuggestions = new JLabel("SID:");
		springLayout.putConstraint(SpringLayout.WEST, lblSuggestions, 160, SpringLayout.WEST, getFrame().getContentPane());
		getFrame().getContentPane().add(lblSuggestions);
		
		JLabel lblComplaints = new JLabel("SINCE:");
		springLayout.putConstraint(SpringLayout.NORTH, lblComplaints, 15, SpringLayout.SOUTH, lblSuggestions);
		springLayout.putConstraint(SpringLayout.WEST, lblComplaints, 160, SpringLayout.WEST, getFrame().getContentPane());
		getFrame().getContentPane().add(lblComplaints);
		
		t1 = new JTextField();
		springLayout.putConstraint(SpringLayout.NORTH, t1, 26, SpringLayout.NORTH, getFrame().getContentPane());
		springLayout.putConstraint(SpringLayout.EAST, t1, 0, SpringLayout.EAST, getFrame().getContentPane());
		getFrame().getContentPane().add(t1);
		t1.setColumns(10);
		
		t2 = new JTextField();
		springLayout.putConstraint(SpringLayout.NORTH, lblSuggestions, 3, SpringLayout.NORTH, t2);
		springLayout.putConstraint(SpringLayout.NORTH, t2, 6, SpringLayout.SOUTH, t1);
		springLayout.putConstraint(SpringLayout.WEST, t2, 0, SpringLayout.WEST, t1);
		getFrame().getContentPane().add(t2);
		t2.setColumns(10);
		
		
	
		
		JToggleButton tglbtnUpdate = new JToggleButton("DELETE");
		springLayout.putConstraint(SpringLayout.SOUTH, list, -6, SpringLayout.NORTH, tglbtnUpdate);
		springLayout.putConstraint(SpringLayout.WEST, tglbtnUpdate, 0, SpringLayout.WEST, getFrame().getContentPane());
		tglbtnUpdate.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try 
				{
					Statement statement = connection.createStatement();
					int i = statement.executeUpdate("DELETE FROM PROVIDES WHERE HID = "
							+ list.getSelectedItem());
					ftf.append("\nDeleted " + i + " rows successfully");
					t1.setText(null);
					t2.setText(null);
					T3.setText(null);
					
					list.removeAll();
					loadList();
				} 
				catch (SQLException insertException) 
				{
					ftf.append(insertException.getMessage());
				}
				
			}
		});
		springLayout.putConstraint(SpringLayout.SOUTH, tglbtnUpdate, 0, SpringLayout.SOUTH, ftf);
		getFrame().getContentPane().add(tglbtnUpdate);
		
		JToggleButton tglbtnBack = new JToggleButton("BACK");
		tglbtnBack.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					DEMO window = new DEMO();
					(window).getfframe().setVisible(true);
				} catch (Exception es) {
					es.printStackTrace();
				}
			}
		});
		springLayout.putConstraint(SpringLayout.SOUTH, tglbtnBack, -10, SpringLayout.SOUTH, getFrame().getContentPane());
		springLayout.putConstraint(SpringLayout.EAST, tglbtnBack, -6, SpringLayout.WEST, ftf);
		getFrame().getContentPane().add(tglbtnBack);
		
		T3 = new JTextField();
		springLayout.putConstraint(SpringLayout.NORTH, T3, 19, SpringLayout.SOUTH, t2);
		springLayout.putConstraint(SpringLayout.EAST, T3, -3, SpringLayout.EAST, getFrame().getContentPane());
		getFrame().getContentPane().add(T3);
		T3.setColumns(10);
	}
	public JFrame getFrame() {
		return frame;
	}
	public void setFrame(JFrame frame) {
		this.frame = frame;
	}
}
