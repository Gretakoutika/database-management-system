import java.awt.EventQueue;

import java.awt.*;
import java.awt.event.*;
import java.sql.*;
import javax.swing.JFrame;
import java.awt.CardLayout;
import javax.swing.SpringLayout;
import java.awt.Color;
import java.awt.TextArea;
import java.awt.List;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.JToggleButton;

public class SUI2 {

	List list = new List(10);
	TextArea ftf;
	private JFrame frame;
	private JTextField t1;
	private JTextField t2;
	private JTextField t3;
	private JTextField t4;
	Connection connection;
	Statement statement;
	ResultSet rs;


	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					SUI2 window = new SUI2();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}
	public SUI2() {
		try 
		{
			Class.forName("oracle.jdbc.driver.OracleDriver");
		} 
		catch (Exception e) 
		{
			System.err.println("Unable to find and load driver");
			System.exit(1);
		}
		connectToDB();
		initialize();
		
	}
	private void connectToDB() {
		// TODO Auto-generated method stub
		try 
		{
		  connection = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","greta","GRETA0910");
		  statement = connection.createStatement();

		} 
		catch (SQLException connectException) 
		{
		  System.out.println(connectException.getMessage());
		  System.out.println(connectException.getSQLState());
		  System.out.println(connectException.getErrorCode());
		  System.exit(1);
		}
    }
	private void loadList() 
	{	   
		try 
		{
		  rs = statement.executeQuery("SELECT SID FROM SERVICES");
		  while (rs.next()) 
		  {
			list.add(rs.getString("SID"));
		  }
		} 
		catch (SQLException e) 
		{ 
		  ftf.append(e.getMessage());
		}
	}
	
	

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.getContentPane().setBackground(new Color(255, 228, 181));
		frame.setBounds(100, 100, 450, 300);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		SpringLayout springLayout = new SpringLayout();
		frame.getContentPane().setLayout(springLayout);
		
		TextArea ftf = new TextArea();
		springLayout.putConstraint(SpringLayout.NORTH, ftf, -81, SpringLayout.SOUTH, frame.getContentPane());
		springLayout.putConstraint(SpringLayout.WEST, ftf, 183, SpringLayout.WEST, frame.getContentPane());
		springLayout.putConstraint(SpringLayout.SOUTH, ftf, -10, SpringLayout.SOUTH, frame.getContentPane());
		springLayout.putConstraint(SpringLayout.EAST, ftf, -21, SpringLayout.EAST, frame.getContentPane());
		frame.getContentPane().add(ftf);
		loadList();
		list.addItemListener(new ItemListener() {
			public void itemStateChanged(ItemEvent arg0) {
				try 
				{
					rs = statement.executeQuery("SELECT * FROM SERVICES where SID ="+list.getSelectedItem());
					rs.next();
					t1.setText(rs.getString("SID"));
					t2.setText(rs.getString("ROOM_COST"));
					t3.setText(rs.getString("FOOD"));
					t4.setText(rs.getString("MAINTENANCE"));
				
				} 
				catch (SQLException selectException) 
				{
					ftf.append(selectException.getMessage());
				}
			}
		});
		frame.getContentPane().add(list);
		
		JLabel lblFid = new JLabel("SID:");
		springLayout.putConstraint(SpringLayout.WEST, lblFid, 160, SpringLayout.WEST, frame.getContentPane());
		springLayout.putConstraint(SpringLayout.EAST, list, -6, SpringLayout.WEST, lblFid);
		springLayout.putConstraint(SpringLayout.NORTH, lblFid, 26, SpringLayout.NORTH, frame.getContentPane());
		frame.getContentPane().add(lblFid);
		
		JLabel lblSuggestions = new JLabel("ROOM COST");
		springLayout.putConstraint(SpringLayout.WEST, lblSuggestions, 160, SpringLayout.WEST, frame.getContentPane());
		frame.getContentPane().add(lblSuggestions);
		
		JLabel lblComplaints = new JLabel("FOOD:");
		springLayout.putConstraint(SpringLayout.WEST, lblComplaints, 160, SpringLayout.WEST, frame.getContentPane());
		frame.getContentPane().add(lblComplaints);
		
		JLabel lblRating = new JLabel("MAINTENANCE:");
		springLayout.putConstraint(SpringLayout.SOUTH, lblComplaints, -6, SpringLayout.NORTH, lblRating);
		frame.getContentPane().add(lblRating);
		
		t1 = new JTextField();
		springLayout.putConstraint(SpringLayout.NORTH, t1, 26, SpringLayout.NORTH, frame.getContentPane());
		springLayout.putConstraint(SpringLayout.EAST, t1, 0, SpringLayout.EAST, frame.getContentPane());
		frame.getContentPane().add(t1);
		t1.setColumns(10);
		
		t2 = new JTextField();
		springLayout.putConstraint(SpringLayout.NORTH, lblSuggestions, 3, SpringLayout.NORTH, t2);
		springLayout.putConstraint(SpringLayout.NORTH, t2, 6, SpringLayout.SOUTH, t1);
		springLayout.putConstraint(SpringLayout.WEST, t2, 0, SpringLayout.WEST, t1);
		frame.getContentPane().add(t2);
		t2.setColumns(10);
		
		t3 = new JTextField();
		springLayout.putConstraint(SpringLayout.NORTH, t3, 3, SpringLayout.SOUTH, t2);
		springLayout.putConstraint(SpringLayout.EAST, t3, 0, SpringLayout.EAST, t1);
		frame.getContentPane().add(t3);
		t3.setColumns(10);
		
		t4 = new JTextField();
		springLayout.putConstraint(SpringLayout.NORTH, lblRating, 3, SpringLayout.NORTH, t4);
		springLayout.putConstraint(SpringLayout.EAST, lblRating, -55, SpringLayout.WEST, t4);
		springLayout.putConstraint(SpringLayout.NORTH, t4, 6, SpringLayout.SOUTH, t3);
		springLayout.putConstraint(SpringLayout.WEST, t4, 0, SpringLayout.WEST, t1);
		frame.getContentPane().add(t4);
		t4.setColumns(10);
		
		JToggleButton tglbtnUpdate = new JToggleButton("UPDATE");
		springLayout.putConstraint(SpringLayout.SOUTH, list, -6, SpringLayout.NORTH, tglbtnUpdate);
		springLayout.putConstraint(SpringLayout.WEST, tglbtnUpdate, 0, SpringLayout.WEST, frame.getContentPane());
		tglbtnUpdate.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {

				try 
				{
					Statement statement = connection.createStatement();
					int i = statement.executeUpdate("UPDATE SERVICES "
					+ "SET ROOM_COST ='" + t2.getText() + "', "
					+ "FOOD = '" + t3.getText() + "',"
					+ "MAINTENANCE = '" + t4.getText()
					+ " 'WHERE SID= "
					+ list.getSelectedItem());
					ftf.append("\nUpdated " + i + " rows successfully");
					list.removeAll();
					loadList();
				} 
				catch (SQLException insertException) 
				{
					ftf.append(insertException.getMessage());
				}
				
			}
		});
		springLayout.putConstraint(SpringLayout.SOUTH, tglbtnUpdate, 0, SpringLayout.SOUTH, ftf);
		frame.getContentPane().add(tglbtnUpdate);
		
		JToggleButton tglbtnBack = new JToggleButton("BACK");
		tglbtnBack.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					DEMO window = new DEMO();
					(window).getfframe().setVisible(true);
				} catch (Exception es) {
					es.printStackTrace();
				}
			}
		});
		springLayout.putConstraint(SpringLayout.SOUTH, tglbtnBack, -10, SpringLayout.SOUTH, frame.getContentPane());
		springLayout.putConstraint(SpringLayout.EAST, tglbtnBack, -6, SpringLayout.WEST, ftf);
		frame.getContentPane().add(tglbtnBack);
	}
}
