import java.awt.EventQueue;
import java.awt.TextArea;

import javax.swing.JFrame;
import java.awt.CardLayout;
import java.awt.Color;
import java.awt.BorderLayout;
import javax.swing.SpringLayout;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.JFormattedTextField;
import javax.swing.JToggleButton;
import javax.swing.JComboBox;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
import java.awt.event.ActionEvent;

public class PRUI1 {
	TextArea ftf = new TextArea();
	Connection connection;
	Statement statement;
	private JFrame frame;
	private JTextField t1;
	private JTextField t2;
	private JTextField t3;

	public PRUI1()
	{
		
		try 
		{
			Class.forName("oracle.jdbc.driver.OracleDriver");
		} 
		catch (Exception e) 
		{
			System.err.println("Unable to find and load driver");
			System.exit(1);
		}
		connectToDB();
		initialize();
	}

	private void connectToDB() {
		// TODO Auto-generated method stub
		try 
		{
		  connection = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","greta","GRETA0910");
		  statement = connection.createStatement();

		} 
		catch (SQLException connectException) 
		{
		  System.out.println(connectException.getMessage());
		  System.out.println(connectException.getSQLState());
		  System.out.println(connectException.getErrorCode());
		  System.exit(1);
		}
    }
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					PRUI1 window = new PRUI1();
					window.getFrame().setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	private void initialize() {
		setFrame(new JFrame());
		getFrame().getContentPane().setBackground(new Color(224, 255, 255));
		SpringLayout springLayout = new SpringLayout();
		springLayout.putConstraint(SpringLayout.SOUTH, ftf, -10, SpringLayout.SOUTH, frame.getContentPane());
		getFrame().getContentPane().setLayout(springLayout);
		
		JLabel lblNewLabel = new JLabel("Hotel ID:");
		springLayout.putConstraint(SpringLayout.WEST, lblNewLabel, 169, SpringLayout.WEST, frame.getContentPane());
		getFrame().getContentPane().add(lblNewLabel);
		
		JLabel lblNewLabel_2 = new JLabel("SERVICE id:");
		springLayout.putConstraint(SpringLayout.NORTH, lblNewLabel_2, 86, SpringLayout.NORTH, frame.getContentPane());
		springLayout.putConstraint(SpringLayout.SOUTH, lblNewLabel, -9, SpringLayout.NORTH, lblNewLabel_2);
		springLayout.putConstraint(SpringLayout.WEST, lblNewLabel_2, 0, SpringLayout.WEST, lblNewLabel);
		getFrame().getContentPane().add(lblNewLabel_2);
		
		JLabel lblNewLabel_3 = new JLabel("SINCE:");
		springLayout.putConstraint(SpringLayout.NORTH, lblNewLabel_3, 12, SpringLayout.SOUTH, lblNewLabel_2);
		springLayout.putConstraint(SpringLayout.WEST, lblNewLabel_3, 0, SpringLayout.WEST, lblNewLabel);
		getFrame().getContentPane().add(lblNewLabel_3);
		
		t1 = new JTextField();
		springLayout.putConstraint(SpringLayout.NORTH, t1, -3, SpringLayout.NORTH, lblNewLabel);
		springLayout.putConstraint(SpringLayout.EAST, t1, -10, SpringLayout.EAST, frame.getContentPane());
		getFrame().getContentPane().add(t1);
		t1.setColumns(10);
		
		t2 = new JTextField();
		springLayout.putConstraint(SpringLayout.NORTH, t2, 6, SpringLayout.SOUTH, lblNewLabel);
		springLayout.putConstraint(SpringLayout.EAST, t2, -10, SpringLayout.EAST, frame.getContentPane());
		getFrame().getContentPane().add(t2);
		t2.setColumns(10);
		
		t3 = new JTextField();
		springLayout.putConstraint(SpringLayout.NORTH, ftf, 38, SpringLayout.SOUTH, t3);
		springLayout.putConstraint(SpringLayout.NORTH, t3, -3, SpringLayout.NORTH, lblNewLabel_3);
		springLayout.putConstraint(SpringLayout.EAST, t3, -10, SpringLayout.EAST, frame.getContentPane());
		getFrame().getContentPane().add(t3);
		t3.setColumns(10);
		springLayout.putConstraint(SpringLayout.WEST, ftf, 0, SpringLayout.WEST, lblNewLabel);
		springLayout.putConstraint(SpringLayout.EAST, ftf, -98, SpringLayout.EAST, getFrame().getContentPane());
		getFrame().getContentPane().add(ftf);
		
		JToggleButton tglbtnUpdateSailor = new JToggleButton("Insert ");
		tglbtnUpdateSailor.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try 
				{
				  Statement statement = connection.createStatement();
				 			  
				  String query= "INSERT INTO provides VALUES(" + t1.getText() + ", "  + t1.getText() + "," +t2.getText() + "," + "'"+ t3.getText()+ "')";
				  int i = statement.executeUpdate(query);
				  ftf.append("\nInserted " + i + " rows successfully");
				} 
				catch (SQLException insertException) 
				{
				  ftf.append(insertException.getMessage());
				}
			}
		}
		);
		springLayout.putConstraint(SpringLayout.NORTH, tglbtnUpdateSailor, 0, SpringLayout.NORTH, ftf);
		springLayout.putConstraint(SpringLayout.EAST, tglbtnUpdateSailor, -16, SpringLayout.WEST, ftf);
		getFrame().getContentPane().add(tglbtnUpdateSailor);
		
		JToggleButton tglbtnBack = new JToggleButton("back");
		tglbtnBack.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					DEMO window = new DEMO();
					(window).getfframe().setVisible(true);
				} catch (Exception es) {
					es.printStackTrace();
				}
			}
		});
		springLayout.putConstraint(SpringLayout.SOUTH, tglbtnBack, 0, SpringLayout.SOUTH, ftf);
		springLayout.putConstraint(SpringLayout.EAST, tglbtnBack, 0, SpringLayout.EAST, t1);
		frame.getContentPane().add(tglbtnBack);
		
		JLabel lblNewLabel_1 = new JLabel("(Enter in \"DD-month-yyyy\" format)");
		springLayout.putConstraint(SpringLayout.NORTH, lblNewLabel_1, 6, SpringLayout.SOUTH, lblNewLabel_3);
		springLayout.putConstraint(SpringLayout.WEST, lblNewLabel_1, 35, SpringLayout.WEST, frame.getContentPane());
		frame.getContentPane().add(lblNewLabel_1);
		getFrame().setBounds(100, 100, 450, 300);
		getFrame().setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}

	public JFrame getFrame() {
		return frame;
	}

	public void setFrame(JFrame frame) {
		this.frame = frame;
	}
}
