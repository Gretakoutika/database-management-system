import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JMenuBar;
import javax.swing.JMenu;
import java.awt.Font;
import java.awt.Color;
import javax.swing.ImageIcon;
import javax.swing.JScrollBar;
import java.awt.BorderLayout;
import javax.swing.JMenuItem;
import javax.swing.JLabel;
import com.jgoodies.forms.factories.DefaultComponentFactory;
import org.eclipse.wb.swing.FocusTraversalOnArray;
import java.awt.Component;
import net.miginfocom.swing.MigLayout;
import com.jgoodies.forms.layout.FormLayout;
import com.jgoodies.forms.layout.ColumnSpec;
import com.jgoodies.forms.layout.FormSpecs;
import com.jgoodies.forms.layout.RowSpec;
import javax.swing.SpringLayout;
import javax.swing.JTextArea;
import javax.swing.JComboBox;
import javax.swing.SwingConstants;
import javax.swing.JTree;
import javax.swing.JToggleButton;
import javax.swing.JFormattedTextField;
import javax.swing.JTextPane;
import javax.swing.JSpinner;
import java.awt.CardLayout;
import java.awt.SystemColor;
import javax.swing.JCheckBoxMenuItem;
import javax.swing.JDesktopPane;
import javax.swing.border.MatteBorder;
import javax.swing.border.TitledBorder;
import javax.swing.border.SoftBevelBorder;
import javax.swing.border.BevelBorder;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class DEMO {

	private JFrame frame;
	private final JLabel lblFeedbackRetrievalSystem = DefaultComponentFactory.getInstance().createTitle("FEEDBACK RETRIEVAL SYSTEM FOR HOTELS");
	
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					DEMO window = new DEMO();
					window.getFrame().setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public DEMO() {
		initialize();
	}

	private void initialize() {
		setFrame(new JFrame());
		getFrame().getContentPane().setFont(new Font("Segoe Print", Font.PLAIN, 22));
		getFrame().getContentPane().setBackground(Color.PINK);
		getFrame().getContentPane().setForeground(Color.PINK);
		getFrame().setBounds(100, 100, 450, 300);
		getFrame().setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		JMenuBar menuBar = new JMenuBar();
		menuBar.setFont(new Font("Times New Roman", Font.PLAIN, 12));
		getFrame().setJMenuBar(menuBar);
		
		JMenu mnNewMenu = new JMenu("PERSONS");
		mnNewMenu.setIcon(new ImageIcon(DEMO.class.getResource("/javax/swing/plaf/metal/icons/ocean/menu.gif")));
		mnNewMenu.setForeground(Color.DARK_GRAY);
		mnNewMenu.setBackground(SystemColor.textHighlight);
		mnNewMenu.setFont(new Font("Lucida Sans", Font.BOLD, 10));
		menuBar.add(mnNewMenu);
		
		JMenuItem mntmInsert = new JMenuItem("INSERT PERSON");
		mntmInsert.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				try {
					PGUI2 window = new PGUI2();
					window.getFrame().setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
				
			}
		});
		mntmInsert.setIcon(new ImageIcon(DEMO.class.getResource("/com/sun/java/swing/plaf/windows/icons/DetailsView.gif")));
		mntmInsert.setHorizontalAlignment(SwingConstants.LEFT);
		mntmInsert.setForeground(Color.DARK_GRAY);
		mntmInsert.setBackground(new Color(255, 228, 181));
		mntmInsert.setFont(new Font("Sitka Small", Font.BOLD, 11));
		mnNewMenu.add(mntmInsert);
		
		JMenuItem mntmView = new JMenuItem(" VIEW PERSON");
		mntmView.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
							PGUI window = new PGUI();
							window.getFrame().setVisible(true);
						} catch (Exception ex) {
							ex.printStackTrace();
						}
					}
				});
		mntmView.setIcon(new ImageIcon(DEMO.class.getResource("/com/sun/java/swing/plaf/windows/icons/DetailsView.gif")));
		mntmView.setHorizontalAlignment(SwingConstants.LEFT);
		mntmView.setBackground(new Color(255, 228, 181));
		mntmView.setFont(new Font("Sitka Small", Font.BOLD, 11));
		mnNewMenu.add(mntmView);
		
		JMenuItem mntmUpdate = new JMenuItem("DELETE PERSON");
		mntmUpdate.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					PGUI3 window = new PGUI3();
					window.getFrame().setVisible(true);
				} catch (Exception v) {
					v.printStackTrace();
				}
			}
		});
		mntmUpdate.setIcon(new ImageIcon(DEMO.class.getResource("/com/sun/java/swing/plaf/windows/icons/DetailsView.gif")));
		mntmUpdate.setBackground(new Color(255, 228, 181));
		mntmUpdate.setFont(new Font("Sitka Small", Font.BOLD, 11));
		mnNewMenu.add(mntmUpdate);
		
		JMenu mnNewMenu_1 = new JMenu("HOTELS");
		mnNewMenu_1.setBackground(SystemColor.textHighlight);
		mnNewMenu_1.setIcon(new ImageIcon(DEMO.class.getResource("/javax/swing/plaf/metal/icons/ocean/menu.gif")));
		mnNewMenu_1.setForeground(Color.DARK_GRAY);
		mnNewMenu_1.setFont(new Font("Lucida Sans", Font.BOLD, 10));
		menuBar.add(mnNewMenu_1);
		
		JMenuItem mntmInsert_1 = new JMenuItem("INSERT HOTEL");
		mntmInsert_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				try {
					HUI1 window = new HUI1();
					window.getFrame().setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
		mntmInsert_1.setIcon(new ImageIcon(DEMO.class.getResource("/com/sun/java/swing/plaf/windows/icons/DetailsView.gif")));
		mntmInsert_1.setFont(new Font("Sitka Small", Font.BOLD, 11));
		mntmInsert_1.setBackground(new Color(255, 228, 181));
		mnNewMenu_1.add(mntmInsert_1);
		
		JMenuItem mntmView_1 = new JMenuItem(" VIEW HOTEL");
		mntmView_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				try {
					HUI2 window = new HUI2();
					window.getFrame().setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
		mntmView_1.setIcon(new ImageIcon(DEMO.class.getResource("/com/sun/java/swing/plaf/windows/icons/DetailsView.gif")));
		mntmView_1.setFont(new Font("Sitka Small", Font.BOLD, 11));
		mntmView_1.setBackground(new Color(255, 228, 181));
		mnNewMenu_1.add(mntmView_1);
		
		JMenuItem mntmUpdate_1 = new JMenuItem("DELETE HOTEL");
		mntmUpdate_1.setIcon(new ImageIcon(DEMO.class.getResource("/com/sun/java/swing/plaf/windows/icons/DetailsView.gif")));
		mntmUpdate_1.setFont(new Font("Sitka Small", Font.BOLD, 11));
		mntmUpdate_1.setBackground(new Color(255, 228, 181));
		mnNewMenu_1.add(mntmUpdate_1);
		
		JMenu mnNewMenu_2 = new JMenu("SERVICES");
		mnNewMenu_2.setBackground(SystemColor.textHighlight);
		mnNewMenu_2.setIcon(new ImageIcon(DEMO.class.getResource("/javax/swing/plaf/metal/icons/ocean/menu.gif")));
		mnNewMenu_2.setFont(new Font("Lucida Sans", Font.BOLD, 10));
		menuBar.add(mnNewMenu_2);
		
		JMenuItem mntmInsert_2 = new JMenuItem("INSERT SERVICES");
		mntmInsert_2.setIcon(new ImageIcon(DEMO.class.getResource("/com/sun/java/swing/plaf/windows/icons/DetailsView.gif")));
		mntmInsert_2.setFont(new Font("Sitka Small", Font.BOLD, 11));
		mntmInsert_2.setBackground(new Color(255, 228, 181));
		mnNewMenu_2.add(mntmInsert_2);
		
		JMenuItem mntmView_2 = new JMenuItem(" VIEW SERVICES");
		mntmView_2.setIcon(new ImageIcon(DEMO.class.getResource("/com/sun/java/swing/plaf/windows/icons/DetailsView.gif")));
		mntmView_2.setHorizontalAlignment(SwingConstants.LEFT);
		mntmView_2.setFont(new Font("Sitka Small", Font.BOLD, 11));
		mntmView_2.setBackground(new Color(255, 228, 181));
		mnNewMenu_2.add(mntmView_2);
		
		JMenuItem mntmUpdate_2 = new JMenuItem("DELETE SERVICE");
		mntmUpdate_2.setIcon(new ImageIcon(DEMO.class.getResource("/com/sun/java/swing/plaf/windows/icons/DetailsView.gif")));
		mntmUpdate_2.setFont(new Font("Sitka Small", Font.BOLD, 11));
		mntmUpdate_2.setBackground(new Color(255, 228, 181));
		mnNewMenu_2.add(mntmUpdate_2);
		
		JMenu mnNewMenu_3 = new JMenu("FEEDBACK ");
		mnNewMenu_3.setIcon(new ImageIcon(DEMO.class.getResource("/javax/swing/plaf/metal/icons/ocean/menu.gif")));
		mnNewMenu_3.setFont(new Font("Lucida Sans", Font.BOLD, 10));
		menuBar.add(mnNewMenu_3);
		
		JMenuItem mntmInsert_3 = new JMenuItem("INSERT FEEDBACK");
		mntmInsert_3.setIcon(new ImageIcon(DEMO.class.getResource("/com/sun/java/swing/plaf/windows/icons/DetailsView.gif")));
		mntmInsert_3.setFont(new Font("Sitka Small", Font.BOLD, 11));
		mntmInsert_3.setBackground(new Color(255, 228, 181));
		mnNewMenu_3.add(mntmInsert_3);
		
		JMenuItem mntmView_3 = new JMenuItem("VIEW FEEDBACKS");
		mntmView_3.setIcon(new ImageIcon(DEMO.class.getResource("/com/sun/java/swing/plaf/windows/icons/DetailsView.gif")));
		mntmView_3.setFont(new Font("Sitka Small", Font.BOLD, 11));
		mntmView_3.setBackground(new Color(255, 228, 181));
		mnNewMenu_3.add(mntmView_3);
		
		JMenuItem mntmUpdate_3 = new JMenuItem("DELETE FEEDBACK");
		mntmUpdate_3.setIcon(new ImageIcon(DEMO.class.getResource("/com/sun/java/swing/plaf/windows/icons/DetailsView.gif")));
		mntmUpdate_3.setFont(new Font("Sitka Small", Font.BOLD, 11));
		mntmUpdate_3.setBackground(new Color(255, 228, 181));
		mnNewMenu_3.add(mntmUpdate_3);
		
		JMenu mnGives = new JMenu("GIVES");
		mnGives.setIcon(new ImageIcon(DEMO.class.getResource("/javax/swing/plaf/metal/icons/ocean/menu.gif")));
		mnGives.setFont(new Font("Lucida Sans", Font.BOLD, 10));
		menuBar.add(mnGives);
		
		JMenuItem mntmInsert_4 = new JMenuItem("INSERT GIVES");
		mntmInsert_4.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					GUI1 window = new GUI1();
					window.getFrame().setVisible(true);
				} catch (Exception eS) {
					eS.printStackTrace();
				}
			}
		});
		mnGives.add(mntmInsert_4);
		
		JMenuItem mntmModifyGives = new JMenuItem("MODIFY GIVES");
		mntmModifyGives.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					GUI2 window = new GUI2();
					window.getFrame().setVisible(true);
				} catch (Exception eZ) {
					eZ.printStackTrace();
				}
			}
		});
		mnGives.add(mntmModifyGives);
		
		JMenuItem mntmDeleteGives = new JMenuItem("DELETE GIVES");
		mntmDeleteGives.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					GUI3 window = new GUI3();
					window.getFrame().setVisible(true);
				} catch (Exception a1) {
					a1.printStackTrace();
				}
			}
		});
		mnGives.add(mntmDeleteGives);
		
		JMenu mnChecks = new JMenu("CHECKS");
		mnChecks.setIcon(new ImageIcon(DEMO.class.getResource("/javax/swing/plaf/metal/icons/ocean/menu.gif")));
		mnChecks.setFont(new Font("Lucida Sans", Font.BOLD, 10));
		menuBar.add(mnChecks);
		
		JMenuItem mntmInsertChecks = new JMenuItem("INSERT CHECKS");
		mntmInsertChecks.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					CUI1 window = new CUI1();
					window.getFrame().setVisible(true);
				} catch (Exception ab) {
					ab.printStackTrace();
				}
				
			}
		});
		mnChecks.add(mntmInsertChecks);
		
		JMenuItem mntmModifyChecks = new JMenuItem("MODIFY CHECKS");
		mntmModifyChecks.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					CUI2 window = new CUI2();
					window.getFrame().setVisible(true);
				} catch (Exception v) {
					v.printStackTrace();
				}
			}
		});
		mnChecks.add(mntmModifyChecks);
		
		JMenuItem mntmDeleteChecks = new JMenuItem("DELETE CHECKS");
		mntmDeleteChecks.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					CUI3 window = new CUI3();
					window.getFrame().setVisible(true);
				} catch (Exception b) {
					b.printStackTrace();
				}
			}
		});
		mnChecks.add(mntmDeleteChecks);
		
		JMenu mnNewMenu_4 = new JMenu("PROVIDES");
		mnNewMenu_4.setIcon(new ImageIcon(DEMO.class.getResource("/javax/swing/plaf/metal/icons/ocean/menu.gif")));
		mnNewMenu_4.setSelectedIcon(new ImageIcon(DEMO.class.getResource("/javax/swing/plaf/metal/icons/ocean/menu.gif")));
		mnNewMenu_4.setFont(new Font("Lucida Sans", Font.BOLD, 10));
		menuBar.add(mnNewMenu_4);
		
		JMenuItem mntmInsertProvides = new JMenuItem("INSERT PROVIDES");
		mntmInsertProvides.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					PRUI1 window = new PRUI1();
					window.getFrame().setVisible(true);
				} catch (Exception eh) {
					eh.printStackTrace();
				}
			}
		});
		mnNewMenu_4.add(mntmInsertProvides);
		
		JMenuItem mntmDeleteProvides = new JMenuItem("DELETE PROVIDES");
		mntmDeleteProvides.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					PRUI3 window = new PRUI3();
					window.getFrame().setVisible(true);
				} catch (Exception p) {
					p.printStackTrace();
				}
			}
		});
		mnNewMenu_4.add(mntmDeleteProvides);
		
		JMenuItem mntmModifyProvides = new JMenuItem("MODIFY PROVIDES");
		mntmModifyProvides.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					PRUI2 window = new PRUI2();
					window.getFrame().setVisible(true);
				} catch (Exception m) {
					m.printStackTrace();
				}
			}
		});
		mnNewMenu_4.add(mntmModifyProvides);
		getFrame().getContentPane().setLayout(new CardLayout(0, 0));
		
		JDesktopPane desktopPane_1 = new JDesktopPane();
		desktopPane_1.setBackground(new Color(204, 102, 153));
		desktopPane_1.setBorder(new MatteBorder(3, 3, 3, 3, (Color) new Color(204, 51, 102)));
		getFrame().getContentPane().add(desktopPane_1, "name_2694331424045200");
		
		JLabel lblNewJgoodiesTitle = DefaultComponentFactory.getInstance().createTitle("FEEDBACK RETRIEVAL SYSTEM FOR HOTELS");
		lblNewJgoodiesTitle.setForeground(new Color(204, 0, 51));
		lblNewJgoodiesTitle.setFont(new Font("Segoe Script", Font.BOLD, 15));
		lblNewJgoodiesTitle.setBounds(21, 83, 422, 48);
		desktopPane_1.add(lblNewJgoodiesTitle);
		getFrame().getContentPane().add(lblFeedbackRetrievalSystem, "name_2692254367048400");
		lblFeedbackRetrievalSystem.setFont(new Font("Courier New", Font.BOLD, 20));
		lblFeedbackRetrievalSystem.setBackground(Color.PINK);
		
		JDesktopPane desktopPane = new JDesktopPane();
		getFrame().getContentPane().add(desktopPane, "name_2694295884714800");
		getFrame().getContentPane().setFocusTraversalPolicy(new FocusTraversalOnArray(new Component[]{lblFeedbackRetrievalSystem}));
	}

	public JFrame getFrame() {
		return frame;
	}

	public void setFrame(JFrame frame) {
		this.frame = frame;
	}

	public Component getfframe() {
		
		return  frame;
	}
}
