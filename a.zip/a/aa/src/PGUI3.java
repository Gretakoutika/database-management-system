import java.awt.EventQueue;
import java.awt.TextArea;

import javax.swing.JFrame;
import java.awt.CardLayout;
import java.awt.Color;
import java.awt.BorderLayout;
import javax.swing.SpringLayout;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.JFormattedTextField;
import javax.swing.JToggleButton;
import javax.swing.JComboBox;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.awt.event.ActionEvent;
import java.awt.List;
import java.awt.event.ItemListener;
import java.awt.event.ItemEvent;

public class PGUI3 {
	TextArea ftf = new TextArea();
	Connection connection;
	Statement statement;
	private JFrame frame;
	private JTextField tfname;
	private JTextField tfid;
	private JTextField tfage;
	private JTextField tfcont;
	private JTextField tfemail;
	List list = new List(10);
	ResultSet rs;

	/**
	 * Launch the application.
	 */
	public PGUI3()
	{
		
		try 
		{
			Class.forName("oracle.jdbc.driver.OracleDriver");
		} 
		catch (Exception e) 
		{
			System.err.println("Unable to find and load driver");
			System.exit(1);
		}
		connectToDB();
		initialize();
	}

	private void connectToDB() {
		// TODO Auto-generated method stub
		try 
		{
		  connection = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","greta","GRETA0910");
		  statement = connection.createStatement();

		} 
		catch (SQLException connectException) 
		{
		  System.out.println(connectException.getMessage());
		  System.out.println(connectException.getSQLState());
		  System.out.println(connectException.getErrorCode());
		  System.exit(1);
		}
    }
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					PGUI3 window = new PGUI3();
					window.getFrame().setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}
	private void loadList() 
	{	   
		try 
		{
		  rs = statement.executeQuery("SELECT PID FROM PERSONS");
		  while (rs.next()) 
		  {
			list.add(rs.getString("PID"));
		  }
		} 
		catch (SQLException e) 
		{ 
		  ftf.append(e.getMessage());
		}
	}
	

	private void initialize() {
		setFrame(new JFrame());
		getFrame().getContentPane().setBackground(Color.PINK);
		SpringLayout springLayout = new SpringLayout();
		getFrame().getContentPane().setLayout(springLayout);
		
		JLabel lblNewLabel = new JLabel("Person Name:");
		getFrame().getContentPane().add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("Person Id:");
		springLayout.putConstraint(SpringLayout.NORTH, lblNewLabel, 13, SpringLayout.SOUTH, lblNewLabel_1);
		springLayout.putConstraint(SpringLayout.WEST, lblNewLabel, 0, SpringLayout.WEST, lblNewLabel_1);
		springLayout.putConstraint(SpringLayout.WEST, lblNewLabel_1, 169, SpringLayout.WEST, getFrame().getContentPane());
		getFrame().getContentPane().add(lblNewLabel_1);
		
		JLabel lblNewLabel_2 = new JLabel("Age:");
		springLayout.putConstraint(SpringLayout.NORTH, lblNewLabel_2, 9, SpringLayout.SOUTH, lblNewLabel);
		springLayout.putConstraint(SpringLayout.WEST, lblNewLabel_2, 0, SpringLayout.WEST, lblNewLabel);
		getFrame().getContentPane().add(lblNewLabel_2);
		
		JLabel lblNewLabel_3 = new JLabel("Contact:");
		springLayout.putConstraint(SpringLayout.WEST, lblNewLabel_3, 0, SpringLayout.WEST, lblNewLabel);
		getFrame().getContentPane().add(lblNewLabel_3);
		
		JLabel lblEmailId = new JLabel("Email Id:");
		springLayout.putConstraint(SpringLayout.NORTH, lblEmailId, 144, SpringLayout.NORTH, getFrame().getContentPane());
		springLayout.putConstraint(SpringLayout.SOUTH, lblNewLabel_3, -6, SpringLayout.NORTH, lblEmailId);
		springLayout.putConstraint(SpringLayout.WEST, lblEmailId, 0, SpringLayout.WEST, lblNewLabel);
		getFrame().getContentPane().add(lblEmailId);
		
		tfname = new JTextField();
		springLayout.putConstraint(SpringLayout.NORTH, tfname, -3, SpringLayout.NORTH, lblNewLabel);
		getFrame().getContentPane().add(tfname);
		tfname.setColumns(10);
		
		tfid = new JTextField();
		springLayout.putConstraint(SpringLayout.WEST, tfname, 0, SpringLayout.WEST, tfid);
		springLayout.putConstraint(SpringLayout.SOUTH, tfid, -197, SpringLayout.SOUTH, getFrame().getContentPane());
		springLayout.putConstraint(SpringLayout.EAST, tfid, -10, SpringLayout.EAST, getFrame().getContentPane());
		springLayout.putConstraint(SpringLayout.NORTH, lblNewLabel_1, 3, SpringLayout.NORTH, tfid);
		getFrame().getContentPane().add(tfid);
		tfid.setColumns(10);
		
		tfage = new JTextField();
		springLayout.putConstraint(SpringLayout.NORTH, tfage, 6, SpringLayout.SOUTH, lblNewLabel);
		springLayout.putConstraint(SpringLayout.EAST, tfage, -10, SpringLayout.EAST, frame.getContentPane());
		getFrame().getContentPane().add(tfage);
		tfage.setColumns(10);
		
		tfcont = new JTextField();
		springLayout.putConstraint(SpringLayout.NORTH, tfcont, -3, SpringLayout.NORTH, lblNewLabel_3);
		springLayout.putConstraint(SpringLayout.EAST, tfcont, -10, SpringLayout.EAST, frame.getContentPane());
		getFrame().getContentPane().add(tfcont);
		tfcont.setColumns(10);
		
		tfemail = new JTextField();
		springLayout.putConstraint(SpringLayout.NORTH, tfemail, 6, SpringLayout.SOUTH, tfcont);
		springLayout.putConstraint(SpringLayout.EAST, tfemail, -10, SpringLayout.EAST, frame.getContentPane());
		getFrame().getContentPane().add(tfemail);
		tfemail.setColumns(10);
		
		
		springLayout.putConstraint(SpringLayout.NORTH, ftf, 6, SpringLayout.SOUTH, tfemail);
		springLayout.putConstraint(SpringLayout.WEST, ftf, 0, SpringLayout.WEST, lblNewLabel);
		springLayout.putConstraint(SpringLayout.SOUTH, ftf, 70, SpringLayout.SOUTH, lblEmailId);
		springLayout.putConstraint(SpringLayout.EAST, ftf, -98, SpringLayout.EAST, getFrame().getContentPane());
		getFrame().getContentPane().add(ftf);
		
		JToggleButton tglbtnUpdateSailor = new JToggleButton("delete");
		springLayout.putConstraint(SpringLayout.SOUTH, tglbtnUpdateSailor, 0, SpringLayout.SOUTH, ftf);
		springLayout.putConstraint(SpringLayout.EAST, tglbtnUpdateSailor, -18, SpringLayout.WEST, ftf);
		tglbtnUpdateSailor.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try 
				{
					Statement statement = connection.createStatement();
					int i = statement.executeUpdate("DELETE FROM PERSONS WHERE PID = "
							+ list.getSelectedItem());
					ftf.append("\nDeleted " + i + " rows successfully");
					tfid.setText(null);
					tfname.setText(null);
					tfcont.setText(null);
					tfage.setText(null);
					tfcont.setText(null);
					tfemail.setText(null);
					list.removeAll();
					loadList();
				} 
				catch (SQLException insertException) 
				{
					ftf.append(insertException.getMessage());
				}
					
			}
		}
		);
		getFrame().getContentPane().add(tglbtnUpdateSailor);
		
		JToggleButton tglbtnBack = new JToggleButton("back");
		tglbtnBack.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					DEMO window = new DEMO();
					(window).getfframe().setVisible(true);
				} catch (Exception es) {
					es.printStackTrace();
				}
			}
		});
		springLayout.putConstraint(SpringLayout.SOUTH, tglbtnBack, 0, SpringLayout.SOUTH, ftf);
		springLayout.putConstraint(SpringLayout.EAST, tglbtnBack, 0, SpringLayout.EAST, tfname);
		frame.getContentPane().add(tglbtnBack);
		
		loadList();
		springLayout.putConstraint(SpringLayout.NORTH, list, 10, SpringLayout.NORTH, frame.getContentPane());
		springLayout.putConstraint(SpringLayout.WEST, list, 0, SpringLayout.WEST, frame.getContentPane());
		list.addItemListener(new ItemListener() {
			public void itemStateChanged(ItemEvent arg0) {
				try 
				{
					rs = statement.executeQuery("SELECT * FROM PERSONS where PID ="+list.getSelectedItem());
					rs.next();
					tfid.setText(rs.getString("PID"));
					tfname.setText(rs.getString("NAME"));
					tfage.setText(rs.getString("AGE"));
					tfcont.setText(rs.getString("CONTACT"));
					tfemail.setText(rs.getString("email_id"));
				
				} 
				catch (SQLException selectException) 
				{
					ftf.append(selectException.getMessage());
				}
			}
		});
		frame.getContentPane().add(list);
		getFrame().setBounds(100, 100, 450, 300);
		getFrame().setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}

	public JFrame getFrame() {
		return frame;
	}

	public void setFrame(JFrame frame) {
		this.frame = frame;
	}
}
