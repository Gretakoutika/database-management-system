import java.awt.EventQueue;
import java.awt.TextArea;

import javax.swing.JFrame;
import java.awt.CardLayout;
import java.awt.Color;
import java.awt.BorderLayout;
import javax.swing.SpringLayout;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.JFormattedTextField;
import javax.swing.JToggleButton;
import javax.swing.JComboBox;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.awt.event.ActionEvent;

public class GUI1 {
	TextArea ftf = new TextArea();
	Connection connection;
	Statement statement;
	private JFrame frame;
	private JTextField t2;
	private JTextField t1;
	private JTextField t3;
	private JTextField t4;

	/**
	 * Launch the application.
	 */
	public GUI1()
	{
		
		try 
		{
			Class.forName("oracle.jdbc.driver.OracleDriver");
		} 
		catch (Exception e) 
		{
			System.err.println("Unable to find and load driver");
			System.exit(1);
		}
		connectToDB();
		initialize();
	}

	private void connectToDB() {
		// TODO Auto-generated method stub
		try 
		{
		  connection = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","greta","GRETA0910");
		  statement = connection.createStatement();

		} 
		catch (SQLException connectException) 
		{
		  System.out.println(connectException.getMessage());
		  System.out.println(connectException.getSQLState());
		  System.out.println(connectException.getErrorCode());
		  System.exit(1);
		}
    }
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					GUI1 window = new GUI1();
					window.getFrame().setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	private void initialize() {
		setFrame(new JFrame());
		getFrame().getContentPane().setBackground(new Color(224, 255, 255));
		SpringLayout springLayout = new SpringLayout();
		springLayout.putConstraint(SpringLayout.SOUTH, ftf, -10, SpringLayout.SOUTH, frame.getContentPane());
		getFrame().getContentPane().setLayout(springLayout);
		
		JLabel lblNewLabel = new JLabel("Hotel ID:");
		getFrame().getContentPane().add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("Person Id:");
		springLayout.putConstraint(SpringLayout.NORTH, lblNewLabel, 13, SpringLayout.SOUTH, lblNewLabel_1);
		springLayout.putConstraint(SpringLayout.WEST, lblNewLabel, 0, SpringLayout.WEST, lblNewLabel_1);
		springLayout.putConstraint(SpringLayout.WEST, lblNewLabel_1, 169, SpringLayout.WEST, getFrame().getContentPane());
		getFrame().getContentPane().add(lblNewLabel_1);
		
		JLabel lblNewLabel_2 = new JLabel("Feedback id:");
		springLayout.putConstraint(SpringLayout.NORTH, lblNewLabel_2, 9, SpringLayout.SOUTH, lblNewLabel);
		springLayout.putConstraint(SpringLayout.WEST, lblNewLabel_2, 0, SpringLayout.WEST, lblNewLabel);
		getFrame().getContentPane().add(lblNewLabel_2);
		
		JLabel lblNewLabel_3 = new JLabel("Time:");
		springLayout.putConstraint(SpringLayout.NORTH, lblNewLabel_3, 12, SpringLayout.SOUTH, lblNewLabel_2);
		springLayout.putConstraint(SpringLayout.WEST, lblNewLabel_3, 0, SpringLayout.WEST, lblNewLabel);
		getFrame().getContentPane().add(lblNewLabel_3);
		
		t2 = new JTextField();
		springLayout.putConstraint(SpringLayout.NORTH, t2, -3, SpringLayout.NORTH, lblNewLabel);
		getFrame().getContentPane().add(t2);
		t2.setColumns(10);
		
		t1 = new JTextField();
		springLayout.putConstraint(SpringLayout.WEST, t2, 0, SpringLayout.WEST, t1);
		springLayout.putConstraint(SpringLayout.SOUTH, t1, -197, SpringLayout.SOUTH, getFrame().getContentPane());
		springLayout.putConstraint(SpringLayout.EAST, t1, -10, SpringLayout.EAST, getFrame().getContentPane());
		springLayout.putConstraint(SpringLayout.NORTH, lblNewLabel_1, 3, SpringLayout.NORTH, t1);
		getFrame().getContentPane().add(t1);
		t1.setColumns(10);
		
		t3 = new JTextField();
		springLayout.putConstraint(SpringLayout.NORTH, t3, 6, SpringLayout.SOUTH, lblNewLabel);
		springLayout.putConstraint(SpringLayout.EAST, t3, -10, SpringLayout.EAST, frame.getContentPane());
		getFrame().getContentPane().add(t3);
		t3.setColumns(10);
		
		t4 = new JTextField();
		t4.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy/MM/dd HH:mm:ss");  
				   LocalDateTime now = LocalDateTime.now();  
				   	t4.setText(dtf.format(now));  
			}
		});
		springLayout.putConstraint(SpringLayout.NORTH, ftf, 38, SpringLayout.SOUTH, t4);
		springLayout.putConstraint(SpringLayout.NORTH, t4, -3, SpringLayout.NORTH, lblNewLabel_3);
		springLayout.putConstraint(SpringLayout.EAST, t4, -10, SpringLayout.EAST, frame.getContentPane());
		getFrame().getContentPane().add(t4);
		t4.setColumns(10);
		springLayout.putConstraint(SpringLayout.WEST, ftf, 0, SpringLayout.WEST, lblNewLabel);
		springLayout.putConstraint(SpringLayout.EAST, ftf, -98, SpringLayout.EAST, getFrame().getContentPane());
		getFrame().getContentPane().add(ftf);
		
		JToggleButton tglbtnUpdateSailor = new JToggleButton("Insert ");
		tglbtnUpdateSailor.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try 
				{
				  Statement statement = connection.createStatement();
				 			  
				  String query= "INSERT INTO GIVES VALUES(" + t1.getText() + ", "  + t2.getText() + "," +t3.getText() + "," + "'" + t4.getText()+ "')";
				  int i = statement.executeUpdate(query);
				  ftf.append("\nInserted " + i + " rows successfully");
				} 
				catch (SQLException insertException) 
				{
				  ftf.append(insertException.getMessage());
				}
			}
		}
		);
		springLayout.putConstraint(SpringLayout.NORTH, tglbtnUpdateSailor, 0, SpringLayout.NORTH, ftf);
		springLayout.putConstraint(SpringLayout.EAST, tglbtnUpdateSailor, -16, SpringLayout.WEST, ftf);
		getFrame().getContentPane().add(tglbtnUpdateSailor);
		
		JToggleButton tglbtnBack = new JToggleButton("back");
		tglbtnBack.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					DEMO window = new DEMO();
					(window).getfframe().setVisible(true);
				} catch (Exception es) {
					es.printStackTrace();
				}
			}
		});
		springLayout.putConstraint(SpringLayout.SOUTH, tglbtnBack, 0, SpringLayout.SOUTH, ftf);
		springLayout.putConstraint(SpringLayout.EAST, tglbtnBack, 0, SpringLayout.EAST, t2);
		frame.getContentPane().add(tglbtnBack);
		getFrame().setBounds(100, 100, 450, 300);
		getFrame().setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}

	public JFrame getFrame() {
		return frame;
	}

	public void setFrame(JFrame frame) {
		this.frame = frame;
	}
}
